What issues will you address by cleaning the data?





Queries:
Below, provide the SQL queries you used to clean your data.
